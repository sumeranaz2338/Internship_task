function LoginForm() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

        if (email == "" ) {
       alert("please enter valid email id: ");
        return false;
    }
    
        if (password.length < 6 ) {
       alert("please enter at least 6 character in password: ");
        return false;
    }

    alert("you are successfully logged in");
    return true;
}