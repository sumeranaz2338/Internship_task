function validateForm(){
    let fname = document.getElementById("fname").value;
    let lname = document.getElementById("lname").value;
    let father = document.getElementById("father").value;
    let mobile = document.getElementById("mobile").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let course = document.getElementById("course").value;
    let gender = document.getElementById("gender").value;
    let genderSelected = false;

    for(let i=0; i<gender.length; i++){
        if(gender[i].checked){
            genderSelected=true;
        }
    }

    if(fname == "" || lname == "" || father == ""){
        alert("please fill all fields: ");
        return false;
    }

    if (mobile == "" ) {
       alert("please enter mobile number: ");
        return false;
    }

        if (email == "" ) {
       alert("please enter valid email id: ");
        return false;
    }
    
        if (password.length < 6 ) {
       alert("please enter at least 6 character in password: ");
        return false;
    }

    if(!genderSelected){
        alert("select gender");
        return false;
    }

    if(course == "" ){
        alert("select course");
        return false;
    }

    alert("you are successfully registerd");
    return true;
}



