// Load tasks when page opens
window.onload = loadTasks;

// Add new task
function addTask() {
    let input = document.getElementById("taskInput");
    let taskText = input.value;

    if (taskText === "") {
        alert("Please enter a task");
        return;
    }

    let tasks = getTasks();
    tasks.push(taskText);
    saveTasks(tasks);

    input.value = "";
    loadTasks();
}

// Display tasks
function loadTasks() {
    let taskList = document.getElementById("taskList");
    taskList.innerHTML = "";

    let tasks = getTasks();

    tasks.forEach((task, index) => {
        let li = document.createElement("li");

        li.innerHTML = `
            ${task}
            <span>
                <button onclick="editTask(${index})">Edit</button>
                <button onclick="deleteTask(${index})">Delete</button>
            </span>
        `;

        taskList.appendChild(li);
    });
}

// Edit task
function editTask(index) {
    let tasks = getTasks();
    let newTask = prompt("Edit task:", tasks[index]);

    if (newTask !== null && newTask !== "") {
        tasks[index] = newTask;
        saveTasks(tasks);
        loadTasks();
    }
}

// Delete task
function deleteTask(index) {
    let tasks = getTasks();
    tasks.splice(index, 1);
    saveTasks(tasks);
    loadTasks();
}

// Get tasks from localStorage
function getTasks() {
    let tasks = localStorage.getItem("tasks");
    return tasks ? JSON.parse(tasks) : [];
}

// Save tasks to localStorage
function saveTasks(tasks) {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}