// EmailJS
(function () {
  emailjs.init("YOUR_PUBLIC_KEY");
})();

// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener("click", e => {
    e.preventDefault();
    document.querySelector(link.getAttribute("href"))
      .scrollIntoView({ behavior: "smooth" });
  });
});

// Reveal
const reveals = document.querySelectorAll(".reveal");
window.addEventListener("scroll", () => {
  reveals.forEach(el => {
    if (el.getBoundingClientRect().top < window.innerHeight - 100) {
      el.classList.add("active");
    }
  });
});

// Hamburger
document.getElementById("hamburger").onclick = () =>
  document.getElementById("navLinks").classList.toggle("active");

// Dark Mode
document.getElementById("themeToggle").onclick = () =>
  document.body.classList.toggle("dark");

// Cursor
const cursor = document.querySelector(".cursor");
document.addEventListener("mousemove", e => {
  cursor.style.left = e.clientX + "px";
  cursor.style.top = e.clientY + "px";
});


// Typing Effect (FIXED & CENTER ALIGNED)
const skills = ["Frontend Developer", "UI Enthusiast", "Web Designer"];
const typing = document.getElementById("typing-text");

let wordIndex = 0;
let charIndex = 0;
let phase = "typing"; // typing | pause | deleting | showAll

function typeEffect() {

  // Show all skills in one line
  if (phase === "showAll") {
    typing.textContent = skills.join(" • ");
    setTimeout(() => {
      phase = "typing";
      wordIndex = 0;
      charIndex = 0;
    }, 2000);
    return;
  }

  let currentWord = skills[wordIndex];

  if (phase === "typing") {
    typing.textContent = currentWord.slice(0, charIndex++);
    if (charIndex > currentWord.length) {
      phase = "pause";
      setTimeout(typeEffect, 800);
      return;
    }
  }

  else if (phase === "pause") {
    phase = "deleting";
  }

  else if (phase === "deleting") {
    typing.textContent = currentWord.slice(0, charIndex--);
    if (charIndex < 0) {
      wordIndex++;
      charIndex = 0;
      phase = wordIndex === skills.length ? "showAll" : "typing";
    }
  }

  setTimeout(typeEffect, phase === "deleting" ? 60 : 120);
}

typeEffect();
