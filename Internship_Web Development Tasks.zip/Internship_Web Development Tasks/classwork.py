import matplotlib.pyplot as plt

# x = [1, 2, 3, 4, 5]
# y = [2, 4, 6, 8, 10]

# plt.plot(x, y)
# plt.xlabel("X values")
# plt.ylabel("Y values")
# plt.title("My first graph")
# plt.show()

# categories = ['A', 'B', 'C', 'D']
# values = [10, 20, 36, 18]


# plt.bar(categories, values)
# plt.title("Bar chart example")
# plt.show()

# import numpy as np
# data = np.random.randn(1000)

# plt.hist(data, bins=50)
# plt.title("Histogram")
# plt.show()

# x = np.random.rand(50)
# y = np.random.rand(50)

# plt.scatter(x, y)
# plt.title("Scatter plot")
# plt.show()

import seaborn as sns
import pandas as pd

df = sns.load_dataset('tips')
df.head()



# sns.boxplot(x='day' , y='total')


# sns.scatterplot(x='total_bill', y='tip', z ='sum' , hue='sex', data=df)
# plt.show()

sns.scatterplot(x='total_bill', y='tip', size='sum', hue='sex', data=df)
plt.show()